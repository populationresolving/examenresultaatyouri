/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import bean.Database;
import bean.User;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author deurd
 */
@WebServlet(name = "ControlServlet", urlPatterns = {"/control"})
public class ControlServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    //hieronder wordt gecontroleerd of er een user is ingelogd en daarmee blijft die ingelogd.
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String page = request.getParameter("page");
        User user = new User();
        
        Cookie[] cookies = request.getCookies();

        for (Cookie aCookie : cookies) {
            String name = aCookie.getName();
            if (name.equals("role")) {
                user.setRole(aCookie.getValue());
                request.setAttribute("role", user.getRole());
            }
            if (name.equals("username")) {
                user.setUsername(aCookie.getValue());
                request.setAttribute("username", user.getUsername());
            }
        }
        //als er een admin is ingelogd gaat die naar adminpage, is er een stagiair ingelogd wordt die doorgestuurd naar stagiairpage
        String url = "/404.jsp";
        switch (page) {
            case "admin":
                url = "/adminpage.jsp";
                break;
            case "stagiair":
                url = "/stagiairpage.jsp";
                break;

        }
        Database database = null;
        try {
            database = new Database();
            ArrayList list = database.getUsers();
            request.setAttribute("userList", list);
        } catch (SQLException | ClassNotFoundException error) {
            System.err.println(error.getCause());
        } finally {
            try {
                database.closeConnection();
            } catch (SQLException ex) {
            }
        }

        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
