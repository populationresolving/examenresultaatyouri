package servlet;

import bean.Database;
import bean.User;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author deurd
 */
@WebServlet(name = "InsertUserServlet", urlPatterns = {"/insertuser"})
public class InsertUserServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String page = request.getParameter("page");
        User loggedInUser = new User();
        User newUser = new User();

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = request.getParameter("role");
        boolean insertuser = true;

        //forward
        String url = "/control?page=admin";
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);

        if (username != null && username.length() > 5 && username.length() < 20) {
            newUser.setPassword(username);
        } else {
            //if the username length is less than 5 of more than 20
            insertuser = false;
            request.setAttribute("error", "de gebruikersnaam moet langer dan 5 en kleiner dan 20 tekens zijn");
        }
        if (password != null && password.length() > 5 && password.length() < 20) {
            newUser.setPassword(password);
        } else {
            //if the password length is less than 5 or more than 20
            insertuser = false;
            request.setAttribute("error", "het wachtwoord moet langer dan 5 en kleiner dan 20 tekens zijn");
        }
        if (role != null) {
            newUser.setRole(role);
        }
        Database database = null;
        Cookie[] cookies = request.getCookies();

        for (Cookie aCookie : cookies) {
            String name = aCookie.getName();
            if (name.equals("role")) {
                loggedInUser.setRole(aCookie.getValue());
                request.setAttribute("role", loggedInUser.getRole());
            }
            if (name.equals("username")) {
                loggedInUser.setUsername(aCookie.getValue());
                request.setAttribute("username", loggedInUser.getUsername());
            }
        }
        //hieronder is de connectie met fucntie insertuser
        try {
            database = new Database();

            if (insertuser) {
                database.insertUser(newUser);
            }
            ArrayList list = database.getUsers();
            request.setAttribute("userList", list);
            if (insertuser) {
                request.setAttribute("error", "User is aangemaakt");
            }
        } catch (SQLException | ClassNotFoundException error) {
            System.err.println(error.getCause());
            request.setAttribute("error", "Deze user bestaat al");
        } finally {
            try {
                database.closeConnection();
            } catch (SQLException ex) {
            }
        }
        dispatcher.forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
