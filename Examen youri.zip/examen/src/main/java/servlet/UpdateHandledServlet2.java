/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import bean.Database;
import bean.Item;
import bean.User;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author yprou
 */
@WebServlet(name = "UpdateHandledServlet2", urlPatterns = {"/updatehandled2"})
public class UpdateHandledServlet2 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String handled = "";
        String id = "";
        boolean handledBoolean = false;
        int idInt = 0;
        try {
            handled = request.getParameter("handled");
            id = request.getParameter("id");
            idInt = Integer.parseInt(id);
            handledBoolean = Boolean.parseBoolean(handled);
        } catch (NumberFormatException error) {
            System.err.println(error.getCause());
        }
        Database database = null;

        Item item = null;
                //hieronder is de connectie met fucntie updateHandled2
        try {
            database = new Database();
            item = database.getItem(idInt);
            item.setHandled(handledBoolean);
            database.updateHandled2(item);
            request.setAttribute("error", "Taak is afgerond");
            ArrayList list = database.getItems();
            request.setAttribute("itemList", list);
            request.setAttribute("getHandledTrueList", list);
        } catch (SQLException | ClassNotFoundException error) {
            System.err.println(error.getCause());
            request.setAttribute("error", "Taak is niet afgerond");
        } finally {
            try {
                database.closeConnection();
            } catch (SQLException ex) {
            }
        }

        String url = "/control?page=stagiair";
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
