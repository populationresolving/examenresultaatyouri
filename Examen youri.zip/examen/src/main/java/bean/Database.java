/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bean;

import java.sql.Connection;
import java.sql.DriverManager;
// import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
// import javafx.concurrent.Task;
// import javax.naming.NamingException;

/**
 *
 * @author deurd
 */
public class Database {

    private Connection connection = null;
    private Statement statement = null;
    private ResultSet resultset = null;

    public Database() throws SQLException, ClassNotFoundException {
        openConnection();
    }

    public void closeConnection() throws SQLException {

        if (resultset != null) {
            resultset.close();
        }
        if (resultset != null) {
            resultset.close();
        }
        if (connection != null) {
            connection.close();
        }
    }
//connectie voor de database

    private void openConnection() throws SQLException, ClassNotFoundException {
        String dbURL = "jdbc:mysql://localhost:3306/examen";
        String username = "root";
        String password = "";

        Class.forName("com.mysql.jdbc.Driver");
        //making the connection
        connection = DriverManager.getConnection(dbURL, username, password);
        statement = (Statement) connection.createStatement();
    }
//query om de gebruikers uit de database op te vragen

    public ArrayList<User> getUsers() throws SQLException, ClassNotFoundException {
        String query = "SELECT username, password, role FROM users";
        ArrayList<User> userList = new ArrayList();;
        resultset = statement.executeQuery(query);
        while (resultset.next()) {
            User user = new User();
            user.setUsername(resultset.getString("username"));
            user.setPassword(resultset.getString("password"));
            user.setRole(resultset.getString("role"));
            userList.add(user);
        }
        return userList;
    }
//query om een enkele user met de juiste combinatie van username en password op te vragen

    public User getUser(String username, String password) throws SQLException, ClassNotFoundException {
        String query = "SELECT username, password, role FROM users"
                + " WHERE username = '" + username + "'"
                + " AND password = '" + password + "'";
        resultset = statement.executeQuery(query);
        User user = new User();
        if (resultset.next()) {
            user.setUsername(resultset.getString("username"));
            user.setPassword(resultset.getString("password"));
            user.setRole(resultset.getString("role"));
            user.setLoggedIn(true);

        }
        closeConnection();
        return user;
    }
//query om een stagiair of admin toe te voegen

    public void insertUser(User user) throws SQLException, ClassNotFoundException {
        String query = "INSERT INTO users(username, password, role) VALUES "
                + "('"
                + user.getUsername()
                + "', '"
                + user.getPassword()
                + "', '"
                + user.getRole()
                + "')";
        statement.executeUpdate(query);
    }
//query om een gebruiker te verwijderen

    public void deleteUser(User user) throws SQLException, ClassNotFoundException {
        String query = "DELETE FROM users"
                + " WHERE username = '" + user.getUsername() + "'";
        statement.executeUpdate(query);
    }
//query om een taak toe te voegen

    public void insertItem(Item item) throws SQLException, ClassNotFoundException {
        String query = "INSERT INTO item(name, description, date) VALUES "
                + "('"
                + item.getName()
                + "', '"
                + item.getDescription()
                + "', '"
                + item.getDate()
                + "')";
        statement.executeUpdate(query);
    }
//query om de taken uit de database op te vragen

    public ArrayList<Item> getItems() throws SQLException, ClassNotFoundException {
        String query = "SELECT id, name, description, date, handled FROM item";
        ArrayList<Item> itemList = new ArrayList();
        resultset = statement.executeQuery(query);
        while (resultset.next()) {
            Item item = new Item();
            item.setId(resultset.getInt("id"));
            item.setName(resultset.getString("name"));
            item.setDescription(resultset.getString("description"));
            item.setDate(resultset.getString("date"));
            item.setHandled(resultset.getBoolean("handled"));
            itemList.add(item);
        }
        return itemList;
    }
//query om de voltooide taken uit de database op te vragen

    public ArrayList<Item> getHandledTrue() throws SQLException, ClassNotFoundException {
        String query = "SELECT id, name, description, date, handled FROM item WHERE handled ='1'";
        ArrayList<Item> getHandledTrueList = new ArrayList();
        resultset = statement.executeQuery(query);
        while (resultset.next()) {
            Item item = new Item();
            item.setId(resultset.getInt("id"));
            item.setName(resultset.getString("name"));
            item.setDescription(resultset.getString("description"));
            item.setDate(resultset.getString("date"));
            item.setHandled(resultset.getBoolean("handled"));
            getHandledTrueList.add(item);
        }
        return getHandledTrueList;
    }
//query om een enkele taak op te vragen met het juiste id

    public Item getItem(int id) throws SQLException, ClassNotFoundException {
        String query = "SELECT id, name, description, date, handled FROM item WHERE id =" + id;
        resultset = statement.executeQuery(query);
        resultset.next();
        Item item = new Item();
        item.setId(resultset.getInt("id"));
        item.setName(resultset.getString("name"));
        item.setDescription(resultset.getString("description"));
        item.setDate(resultset.getString("date"));
        item.setHandled(resultset.getBoolean("handled"));
        return item;
    }
//query om een taak te laten voltooien

    public void updateHandled(Item item) throws SQLException, ClassNotFoundException {
        String query = "UPDATE item SET handled = '1' WHERE `item`.`id` = " + item.getId();
        statement.executeUpdate(query);
    }
//query om een taak te laten onvoltooien

    public void updateHandled2(Item item) throws SQLException, ClassNotFoundException {
        String query = "UPDATE item SET handled = '0' WHERE `item`.`id` = " + item.getId();
        statement.executeUpdate(query);
    }
//query om een specifieke taak te verwijderen    

    public void deleteTask(Item item) throws SQLException, ClassNotFoundException {
        String query = "DELETE FROM item WHERE `item`.`id` = " + item.getId();
        statement.executeUpdate(query);
    }
//query om een gebruikersnaam te veranderen

    public void updateUser(String oldUsername, String newUsername) throws SQLException, ClassNotFoundException {
        String query = "UPDATE users SET username = '" + newUsername + "' WHERE users.username = '" + oldUsername + "'";
        statement.executeUpdate(query);
    }
//query om de naam van een taak te veranderen

    public void updateItem(String newName, int id) throws SQLException, ClassNotFoundException {
        String query = "UPDATE item SET name = '" + newName + "' WHERE item.id = '" + id + "'";
        statement.executeUpdate(query);
    }
}
